var config = {
    apiKey: "AIzaSyDualeCKXi7JKIFMaCXBwiUEeHHJPFCJUI",
    authDomain: "cp-hackathon.firebaseapp.com",
    databaseURL: "https://cp-hackathon.firebaseio.com",
    projectId: "cp-hackathon",
    storageBucket: "cp-hackathon.appspot.com",
    messagingSenderId: "272124965022"
};

export default config;